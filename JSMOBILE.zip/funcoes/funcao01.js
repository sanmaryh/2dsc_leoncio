//Atividades funções Javascript
// 1) Funçao soma(n1,n2)
// 2) Funçao soma(n1,n2) com checagem if/else
// 3 funçao nomeAltura(nome,altura)com checagem if/else
// 4) funçao numeroParOuImpar(n1)
// 5) funçao numeroParOuImpar(n1) com checagem if/else

function dados1(nome,altura) {
  console.log("Olá" + nome + "sua altura é" + altura)
}

fuction soma1(n1,n2){
  cont res = n1 + n2
  console.log("resultado: "+re)
}
//soma1("abobora",20)

fuction soma2(n1,n2){
  if(type n1 === "number" && typeof n2 ==="number") {
  cont res = n1 + n2
  console.log("resultado: "+re)
}else {console.log("erro")}o}